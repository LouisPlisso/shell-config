module Data.Function.HT (
   nest, powerAssociative, compose2,
   ) where

import Data.Function.HT.Private (nest, powerAssociative, )

{- |
Known as @on@ in newer versions of the @base@ package.
-}
{-# INLINE compose2 #-}
compose2 :: (b -> b -> c) -> (a -> b) -> (a -> a -> c)
compose2 g f x y = g (f x) (f y)

module Data.List.Match (
   L.take,
   L.drop,
   L.splitAt,
   L.replicate,
   L.compareLength,
   L.lessOrEqualLength,
   L.shorterList,
   ) where

import qualified Data.List.Match.Private as L

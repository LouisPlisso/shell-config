module Data.String.HT where

import Data.Char (isSpace, )
import Data.List.HT (dropWhileRev, )

-- | remove leading and trailing spaces
trim :: String -> String
trim = dropWhileRev isSpace . dropWhile isSpace

{-# LANGUAGE TemplateHaskell #-}
module Data.Accessor.Template.Example where

import qualified Data.Accessor.Template as AT

data Foo a =
   Bar { x_ :: a } |
   Qux { x_ :: a }

$( AT.deriveAccessors ''Foo )


data HigherKind tycon =
   HigherKind {
      y_ :: tycon Int,
      z_ :: tycon Char
   }

$( AT.deriveAccessors ''HigherKind )

import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as B8
import System.IO
import System.Environment

countChar :: Char -> B.ByteString -> Integer
countChar c = B8.foldl' (\acc c' -> if c' == c then acc + 1 else acc) 0

countHandle :: Handle -> IO Integer
countHandle h = loop 0 where
	loop acc = do
		bytes <- B.hGet h 4096
		if B.null bytes
			then return acc
			else let acc' = acc + countChar '\n' bytes in loop $! acc'

main :: IO ()
main = do
	filename:_ <- getArgs
	h <- openBinaryFile filename ReadMode
	countHandle h >>= print

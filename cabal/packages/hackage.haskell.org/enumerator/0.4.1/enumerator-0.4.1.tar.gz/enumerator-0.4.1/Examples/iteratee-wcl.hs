module Main (main) where
import Data.Iteratee
import Data.Iteratee.IO
import Data.Iteratee.WrappedByteString
import Data.Word (Word8)
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as B8
import System.IO
import System.Environment

iterLines :: Monad m => IterateeG WrappedByteString Word8 m Integer
iterLines = IterateeG (step 0) where
	step acc s@(EOF _) = return $ Done acc s
	step acc (Chunk wrapped) = return $ Cont (IterateeG (step $! acc')) Nothing where
		acc' = acc + countChar '\n' (unWrap wrapped)

countChar :: Char -> B.ByteString -> Integer
countChar c = B8.foldl (\acc c' -> if c' == c then acc + 1 else acc) 0

main :: IO ()
main = do
	filename:_ <- getArgs
	h <- openBinaryFile filename ReadMode
	enumHandle h iterLines >>= run >>= print

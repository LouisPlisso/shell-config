import qualified Data.ByteString.Lazy as B
import qualified Data.ByteString.Lazy.Char8 as B8
import System.IO
import System.Environment

countChar :: Char -> B.ByteString -> Integer
countChar c = B8.foldl' (\acc c' -> if c' == c then acc + 1 else acc) 0

countHandle :: Handle -> IO Integer
countHandle h = fmap (countChar '\n') (B.hGetContents h)

main :: IO ()
main = do
	filename:_ <- getArgs
	h <- openBinaryFile filename ReadMode
	countHandle h >>= print

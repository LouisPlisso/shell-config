module Main (main) where
import Data.Enumerator
import Data.Enumerator.IO
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as B8
import System.IO
import System.Environment

iterLines :: Monad m => Iteratee e B.ByteString m Integer
iterLines = continue (step 0) where
	step acc EOF = yield acc EOF
	step acc (Chunks xs) = continue $ step $! foldl foldStep acc xs
	foldStep acc bytes = acc + countChar '\n' bytes

countChar :: Char -> B.ByteString -> Integer
countChar c = B8.foldl (\acc c' -> if c' == c then acc + 1 else acc) 0

main :: IO ()
main = do
	filename:_ <- getArgs
	h <- openBinaryFile filename ReadMode
	run (iterLines >>== enumHandle 4096 h) >>= print
